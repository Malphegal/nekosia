function initData() {
  jimData.variables["user_name"] = "";
  jimData.variables["topic_name"] = "";
  jimData.variables["topic_first_msg"] = "";
  jimData.variables["topic_owner"] = "";
  jimData.isInitialized = true;
}