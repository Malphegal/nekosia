(function(window, undefined) {

  var jimLinks = {
    "1fb17292-4b39-4aa9-b71c-e445368e078f" : {
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Text_1" : [
        "c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6"
      ],
      "Text_6" : [
        "c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6"
      ],
      "Text_11" : [
        "c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6"
      ],
      "Text_16" : [
        "c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6"
      ],
      "Text_21" : [
        "c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6"
      ],
      "Text_26" : [
        "c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6"
      ]
    },
    "c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6" : {
      "btn_back_index" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "2a6ff5d5-5f64-4efc-bb8b-59b6900f7e0e" : {
      "btn_back_index" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "cf63c592-a81b-4bd2-8455-dd507c76aeba" : {
      "img_profil_mini" : [
        "1fb17292-4b39-4aa9-b71c-e445368e078f",
        "2a6ff5d5-5f64-4efc-bb8b-59b6900f7e0e"
      ],
      "img_profil_arrow" : [
        "1fb17292-4b39-4aa9-b71c-e445368e078f",
        "2a6ff5d5-5f64-4efc-bb8b-59b6900f7e0e"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);