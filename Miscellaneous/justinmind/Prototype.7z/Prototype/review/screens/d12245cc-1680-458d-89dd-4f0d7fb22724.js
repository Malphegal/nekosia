var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1920" deviceHeight="1080">\
    <div id="t-cf63c592-a81b-4bd2-8455-dd507c76aeba" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="MainTemplate" width="1920" height="1080">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185-ie8.css" /><![endif]-->\
      <div id="t-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="1921px" datasizeheight="816px" dataX="0" dataY="264" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Dynamic_Panel_1" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="1920px" datasizeheight="267px" dataX="0" dataY="0" >\
        <div id="t-Panel_1" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="1920px" datasizeheight="267px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="t-lbl_title" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="98px" datasizeheight="32px" dataX="911" dataY="212" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-lbl_title_0">Nekosia</span></div></div></div></div>\
              <div id="t-canvasPanel" class="group firer ie-background commentable non-processed" datasizewidth="72px" datasizeheight="56px" dataX="1375" dataY="204" >\
                <div id="t-fill" class="pie rectangle firer commentable non-processed"   datasizewidth="72px" datasizeheight="56px" dataX="0" dataY="0" >\
                 <div class="backgroundLayer"></div>\
                 <div class="paddingLayer">\
                   <div class="clipping">\
                     <div class="content">\
                       <div class="valign">\
                         <span id="rtr-t-fill_0"></span>\
                       </div>\
                     </div>\
                   </div>\
                 </div>\
                </div>\
                <div id="t-stroke" class="pie image firer ie-background commentable non-processed"   datasizewidth="72px" datasizeheight="56px" dataX="0" dataY="0"   alt="image" systemName="./images/87b9b3b0-2229-462d-a343-1179e5c595b0.svg" overlay="#B8BBBD">\
                    <?xml version="1.0" encoding="utf-8"?>\
                    <!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
                    <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
                    <svg preserveAspectRatio=\'none\' version="1.1" id="t-stroke-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
                    	 width="609px" height="427px" viewBox="0 0 609 427" enable-background="new 0 0 609 427" xml:space="preserve">\
                    <g>\
                    	<g>\
                    		<g>\
                    			<path fill="#959A9D" d="M506.202,0.792c-118.468,0.38-237.21-0.566-352.284-0.586c-51.235,0-102.187,0-151.975,0.001H0.586v1.357\
                    				c0.055,144.49,0.107,285.629,0.161,423.685v1.196h1.195c169.352,0.045,333.996,0.088,494.081,0.13\
                    				c24.285,0.016,64.24,0.042,89.143,0.058c51.731-0.086-0.561-1.601-25.313-1.813c-155.4-1.352-325.249-1.101-462.638-0.659\
                    				c-31.797,0.082-63.576,0.165-95.273,0.248l0.843,0.842C2.5,283.491,2.558,142.154,2.703,1.564l-0.76,0.759\
                    				c203.414,0.21,405.409,0.601,605.264,0.388l-1.146-1.146c0.131,122.829,0.489,244.842,1.258,365.887\
                    				c0.108,16.961,0.544,88.711,1.054,42.538c0.521-47.271,0.156-140.818,0.104-161.295c-0.091-79.919-0.185-162.561-0.28-247.13\
                    				l-0.001-0.99l-0.987,0.002C574.073,0.647,540.211,0.72,506.202,0.792z M548.615,1.18c-2.202-0.19,14.225-0.589,17.015-0.349\
                    				C567.83,1.02,551.405,1.42,548.615,1.18z"/>\
                    		</g>\
                    	</g>\
                    </g>\
                    </svg>\
\
                </div>\
              </div>\
\
              <div id="t-img_profil_mini" class="pie image firer click ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="1384" dataY="212"   alt="image">\
                  <img src="resources/jim/images/common/cross.svg" />\
              </div>\
\
              <div id="t-img_header" class="pie image firer ie-background commentable non-processed"   datasizewidth="1300px" datasizeheight="194px" dataX="310" dataY="0"   alt="image">\
                  <img src="resources/jim/images/common/cross.svg" />\
              </div>\
              <div id="t-img_profil_arrow" class="pie image firer click ie-background commentable non-processed"   datasizewidth="15px" datasizeheight="7px" dataX="1427" dataY="246"   alt="image" systemName="./images/d5f0855b-91d4-4241-9003-f3fbd329993e.svg" overlay="#434343">\
                  <?xml version="1.0" encoding="UTF-8"?>\
                  <svg preserveAspectRatio=\'none\' width="23px" height="13px" viewBox="0 0 23 13" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                      <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
                      <title>Arrow Left</title>\
                      <desc>Created with Sketch.</desc>\
                      <defs></defs>\
                      <g id="t-img_profil_arrow-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                          <g id="t-img_profil_arrow-Components" transform="translate(-658.000000, -518.000000)" fill="#CBCBCB">\
                              <g id="t-img_profil_arrow-Inputs" transform="translate(100.000000, 498.000000)">\
                                  <g id="t-img_profil_arrow-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
                                      <polyline transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0"></polyline>\
                                  </g>\
                              </g>\
                          </g>\
                      </g>\
                  </svg>\
              </div>\
              <div id="t-lbl_user_name" class="pie label singleline autofit firer pageload ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="16px" dataX="1452" dataY="223" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-lbl_user_name_0"></span></div></div></div></div>\
\
          </div>\
        </div>\
      </div>\
      <div id="t-rect_already_connected" class="pie rectangle firer commentable hidden non-processed"   datasizewidth="183px" datasizeheight="77px" dataX="1163" dataY="231" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-rect_already_connected_0"></span><span id="rtr-t-rect_already_connected_1">Vous &ecirc;tes d&eacute;j&agrave; connect&eacute;.</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="center" name="Index" width="1920" height="1080">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1585314032185.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1585314032185-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1585314032185-ie8.css" /><![endif]-->\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="1300px" datasizeheight="80px" dataX="310" dataY="290" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-topic_1" class="pie rectangle firer click commentable non-processed"   datasizewidth="1000px" datasizeheight="90px" dataX="310" dataY="406" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-topic_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_1" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="380px" datasizeheight="24px" dataX="419" dataY="418" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_1_0">Les beignets &agrave; la fraise. On en parle ?</span></div></div></div></div>\
      <div id="s-Text_2" class="pie label multiline autofit firer ie-background commentable non-processed"   datasizewidth="421px" datasizeheight="32px" dataX="419" dataY="448" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Hey ! Bonjour &agrave; tous.</span><span id="s-abe81a04"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="50px" dataX="329" dataY="411"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_3" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="49px" datasizeheight="16px" dataX="330" dataY="466" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_3_0">Arthur64</span></div></div></div></div>\
      <div id="s-Text_4" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="62px" datasizeheight="16px" dataX="1240" dataY="471" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_4_0">7 045 vues</span></div></div></div></div>\
      <div id="s-Text_5" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="16px" dataX="1240" dataY="443" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_5_0">45 postes</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"   datasizewidth="56px" datasizeheight="1px" dataX="1243" dataY="466" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 0 L 56 0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-topic_2" class="pie rectangle firer commentable non-processed"   datasizewidth="1000px" datasizeheight="90px" dataX="310" dataY="519" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-topic_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_6" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="629px" datasizeheight="24px" dataX="419" dataY="531" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_6_0">Comment on fais pr faire un gateau avec des myrties dedant ?</span></div></div></div></div>\
      <div id="s-Text_7" class="pie label multiline autofit firer ie-background commentable non-processed"   datasizewidth="465px" datasizeheight="32px" dataX="419" dataY="561" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_7_0">Chai pas quand m&egrave;tre les myrties la dans la pate avant de m&egrave;tre dans le four ??!<br />Je v...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="50px" dataX="329" dataY="524"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_8" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="52px" datasizeheight="16px" dataX="330" dataY="579" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_8_0">SaBRr1n</span></div></div></div></div>\
      <div id="s-Text_9" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="44px" datasizeheight="16px" dataX="1240" dataY="584" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_9_0">30</span><span id="rtr-s-Text_9_1"> vues</span></div></div></div></div>\
      <div id="s-Text_10" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="50px" datasizeheight="16px" dataX="1240" dataY="556" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_10_0">6</span><span id="rtr-s-Text_10_1"> postes</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_2" class="shapewrapper shapewrapper-s-Line_2 non-processed"   datasizewidth="56px" datasizeheight="1px" dataX="1243" dataY="579" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_2" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_2" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 0 L 56 0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-topic_3" class="pie rectangle firer commentable non-processed"   datasizewidth="1000px" datasizeheight="90px" dataX="310" dataY="627" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-topic_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_11" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="241px" datasizeheight="24px" dataX="419" dataY="639" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_11_0">se filmer pour un devoir</span></div></div></div></div>\
      <div id="s-Text_12" class="pie label multiline autofit firer ie-background commentable non-processed"   datasizewidth="674px" datasizeheight="32px" dataX="419" dataY="669" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_12_0">salut les kheys, ma prof d&#039;anglais nous demande de se filmer entrain de r&eacute;citer un discours en anglais mais on est d&#039;accord qu&#039;elle a pas le droit ? Fin je suis...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="50px" dataX="329" dataY="632"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_13" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="59px" datasizeheight="16px" dataX="330" dataY="687" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_13_0">LeSUPER</span></div></div></div></div>\
      <div id="s-Text_14" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="16px" dataX="1240" dataY="692" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_14_0">542</span><span id="rtr-s-Text_14_1"> vues</span></div></div></div></div>\
      <div id="s-Text_15" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="16px" dataX="1240" dataY="664" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_15_0">46 postes</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_3" class="shapewrapper shapewrapper-s-Line_3 non-processed"   datasizewidth="56px" datasizeheight="1px" dataX="1243" dataY="687" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_3" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_3" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 0 L 56 0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-topic_4" class="pie rectangle firer commentable non-processed"   datasizewidth="1000px" datasizeheight="90px" dataX="310" dataY="737" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-topic_4_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_16" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="734px" datasizeheight="24px" dataX="419" dataY="749" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_16_0">l</span><span id="rtr-s-Text_16_1">a vie d&#039;un &ecirc;tre humain est aussi prestigieuse que celle d&#039;un unicellulaire.</span></div></div></div></div>\
      <div id="s-Text_17" class="pie label multiline autofit firer ie-background commentable non-processed"   datasizewidth="43px" datasizeheight="32px" dataX="419" dataY="779" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_17_0">[Image]<br />Voil&agrave;.</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="50px" dataX="329" dataY="742"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_18" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="86px" datasizeheight="16px" dataX="320" dataY="797" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_18_0">XX_KILLER_XX</span></div></div></div></div>\
      <div id="s-Text_19" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="69px" datasizeheight="16px" dataX="1233" dataY="802" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_19_0">68</span><span id="rtr-s-Text_19_1"> 255 vues</span></div></div></div></div>\
      <div id="s-Text_20" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="16px" dataX="1240" dataY="774" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_20_0">57</span><span id="rtr-s-Text_20_1"> postes</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_4" class="shapewrapper shapewrapper-s-Line_4 non-processed"   datasizewidth="56px" datasizeheight="1px" dataX="1243" dataY="797" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_4" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_4" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 0 L 56 0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-topic_5" class="pie rectangle firer commentable non-processed"   datasizewidth="1000px" datasizeheight="90px" dataX="310" dataY="842" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-topic_5_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_21" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="247px" datasizeheight="24px" dataX="419" dataY="854" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_21_0">&Ccedil;a fait 10 min je rit de &ccedil;a</span></div></div></div></div>\
      <div id="s-Text_22" class="pie label multiline autofit firer ie-background commentable non-processed"   datasizewidth="288px" datasizeheight="32px" dataX="419" dataY="884" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_22_0">[Image] </span><span id="rtr-s-Text_22_1">Bordel mais Tema son long nez frr<br />Son nez qui descend jusqu&#039;en enfer nn c trop &nbsp; &nbsp; &nbsp; </span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="50px" dataX="329" dataY="847"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_23" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="74px" datasizeheight="16px" dataX="322" dataY="903" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_23_0">_m_princess</span></div></div></div></div>\
      <div id="s-Text_24" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="62px" datasizeheight="16px" dataX="1240" dataY="907" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_24_0">1 941</span><span id="rtr-s-Text_24_1"> vues</span></div></div></div></div>\
      <div id="s-Text_25" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="16px" dataX="1240" dataY="879" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_25_0">30</span><span id="rtr-s-Text_25_1"> postes</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_5" class="shapewrapper shapewrapper-s-Line_5 non-processed"   datasizewidth="56px" datasizeheight="1px" dataX="1243" dataY="902" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_5" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_5" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 0 L 56 0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-topic_6" class="pie rectangle firer commentable non-processed"   datasizewidth="1000px" datasizeheight="90px" dataX="310" dataY="946" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-topic_6_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_26" class="pie label singleline autofit firer click ie-background commentable non-processed"   datasizewidth="251px" datasizeheight="24px" dataX="419" dataY="958" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_26_0">Nintendo Switch ou Wii U</span></div></div></div></div>\
      <div id="s-Text_27" class="pie label multiline autofit firer ie-background commentable non-processed"   datasizewidth="661px" datasizeheight="32px" dataX="419" dataY="988" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_27_0">Bonjour, il y a longtemps j&#039;ai vendu ma Wii U, mais d&eacute;sormais les jeux comme Super Mario 3D world ou Mario maker... Me manque donc je voudrais...</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed"   datasizewidth="51px" datasizeheight="50px" dataX="329" dataY="951"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Text_28" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="88px" datasizeheight="16px" dataX="322" dataY="1006" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_28_0">Sarah_Tatouille</span></div></div></div></div>\
      <div id="s-Text_29" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="60px" datasizeheight="16px" dataX="1240" dataY="1011" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_29_0">8</span><span id="rtr-s-Text_29_1"> 111 vues</span></div></div></div></div>\
      <div id="s-Text_30" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="57px" datasizeheight="16px" dataX="1240" dataY="983" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-Text_30_0">17</span><span id="rtr-s-Text_30_1"> postes</span></div></div></div></div>\
      <div id="shapewrapper-s-Line_6" class="shapewrapper shapewrapper-s-Line_6 non-processed"   datasizewidth="56px" datasizeheight="1px" dataX="1243" dataY="1006" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_6" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_6" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 0 L 56 0"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="289px" datasizeheight="630px" dataX="1320" dataY="406" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-Text_31" class="pie label multiline autofit firer ie-background commentable non-processed"   datasizewidth="208px" datasizeheight="246px" dataX="1345" dataY="418" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_31_0">[Les stats du site</span><span id="rtr-s-Text_31_1">s]<br /><br /><br /><br /><br /><br /><br /><br />[Les postes les plus vues de la journ&eacute;e]<br /><br /><br /><br /><br /><br /></span><span id="rtr-s-Text_31_2"><br />[Les postes randoms]</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-lbl_new_topic" class="pie label singleline autofit firer pageload ie-background commentable hidden non-processed"   datasizewidth="89px" datasizeheight="16px" dataX="365" dataY="328" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-lbl_new_topic_0">Nouveau topic :</span></div></div></div></div>\
      <div id="s-txt_new_topic" class="pie text firer commentable hidden non-processed"  datasizewidth="214px" datasizeheight="29px" dataX="462" dataY="321" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div>\
      <div id="s-btn_new_topic" class="pie button singleline firer click ie-background commentable hidden non-processed"   datasizewidth="68px" datasizeheight="29px" dataX="692" dataY="321" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-btn_new_topic_0">Cr&eacute;er</span></div></div></div></div>\
      <div id="s-rect_new_topic_created" class="pie rectangle firer commentable hidden non-processed"   datasizewidth="183px" datasizeheight="56px" dataX="784" dataY="306" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-rect_new_topic_created_0">Nouveau topic !<br />(</span><span id="rtr-s-rect_new_topic_created_1">Rien pour l&#039;instant dans la simulation)</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;