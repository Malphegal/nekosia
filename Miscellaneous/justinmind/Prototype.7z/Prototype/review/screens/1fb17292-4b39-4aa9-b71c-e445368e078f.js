var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1920" deviceHeight="1080">\
    <div id="t-cf63c592-a81b-4bd2-8455-dd507c76aeba" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="MainTemplate" width="1920" height="1080">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185-ie8.css" /><![endif]-->\
      <div id="t-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="1921px" datasizeheight="816px" dataX="0" dataY="264" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Dynamic_Panel_1" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="1920px" datasizeheight="267px" dataX="0" dataY="0" >\
        <div id="t-Panel_1" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="1920px" datasizeheight="267px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="t-lbl_title" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="98px" datasizeheight="32px" dataX="911" dataY="212" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-lbl_title_0">Nekosia</span></div></div></div></div>\
              <div id="t-canvasPanel" class="group firer ie-background commentable non-processed" datasizewidth="72px" datasizeheight="56px" dataX="1375" dataY="204" >\
                <div id="t-fill" class="pie rectangle firer commentable non-processed"   datasizewidth="72px" datasizeheight="56px" dataX="0" dataY="0" >\
                 <div class="backgroundLayer"></div>\
                 <div class="paddingLayer">\
                   <div class="clipping">\
                     <div class="content">\
                       <div class="valign">\
                         <span id="rtr-t-fill_0"></span>\
                       </div>\
                     </div>\
                   </div>\
                 </div>\
                </div>\
                <div id="t-stroke" class="pie image firer ie-background commentable non-processed"   datasizewidth="72px" datasizeheight="56px" dataX="0" dataY="0"   alt="image" systemName="./images/87b9b3b0-2229-462d-a343-1179e5c595b0.svg" overlay="#B8BBBD">\
                    <?xml version="1.0" encoding="utf-8"?>\
                    <!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
                    <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
                    <svg preserveAspectRatio=\'none\' version="1.1" id="t-stroke-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
                    	 width="609px" height="427px" viewBox="0 0 609 427" enable-background="new 0 0 609 427" xml:space="preserve">\
                    <g>\
                    	<g>\
                    		<g>\
                    			<path fill="#959A9D" d="M506.202,0.792c-118.468,0.38-237.21-0.566-352.284-0.586c-51.235,0-102.187,0-151.975,0.001H0.586v1.357\
                    				c0.055,144.49,0.107,285.629,0.161,423.685v1.196h1.195c169.352,0.045,333.996,0.088,494.081,0.13\
                    				c24.285,0.016,64.24,0.042,89.143,0.058c51.731-0.086-0.561-1.601-25.313-1.813c-155.4-1.352-325.249-1.101-462.638-0.659\
                    				c-31.797,0.082-63.576,0.165-95.273,0.248l0.843,0.842C2.5,283.491,2.558,142.154,2.703,1.564l-0.76,0.759\
                    				c203.414,0.21,405.409,0.601,605.264,0.388l-1.146-1.146c0.131,122.829,0.489,244.842,1.258,365.887\
                    				c0.108,16.961,0.544,88.711,1.054,42.538c0.521-47.271,0.156-140.818,0.104-161.295c-0.091-79.919-0.185-162.561-0.28-247.13\
                    				l-0.001-0.99l-0.987,0.002C574.073,0.647,540.211,0.72,506.202,0.792z M548.615,1.18c-2.202-0.19,14.225-0.589,17.015-0.349\
                    				C567.83,1.02,551.405,1.42,548.615,1.18z"/>\
                    		</g>\
                    	</g>\
                    </g>\
                    </svg>\
\
                </div>\
              </div>\
\
              <div id="t-img_profil_mini" class="pie image firer click ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="1384" dataY="212"   alt="image">\
                  <img src="resources/jim/images/common/cross.svg" />\
              </div>\
\
              <div id="t-img_header" class="pie image firer ie-background commentable non-processed"   datasizewidth="1300px" datasizeheight="194px" dataX="310" dataY="0"   alt="image">\
                  <img src="resources/jim/images/common/cross.svg" />\
              </div>\
              <div id="t-img_profil_arrow" class="pie image firer click ie-background commentable non-processed"   datasizewidth="15px" datasizeheight="7px" dataX="1427" dataY="246"   alt="image" systemName="./images/d5f0855b-91d4-4241-9003-f3fbd329993e.svg" overlay="#434343">\
                  <?xml version="1.0" encoding="UTF-8"?>\
                  <svg preserveAspectRatio=\'none\' width="23px" height="13px" viewBox="0 0 23 13" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                      <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
                      <title>Arrow Left</title>\
                      <desc>Created with Sketch.</desc>\
                      <defs></defs>\
                      <g id="t-img_profil_arrow-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                          <g id="t-img_profil_arrow-Components" transform="translate(-658.000000, -518.000000)" fill="#CBCBCB">\
                              <g id="t-img_profil_arrow-Inputs" transform="translate(100.000000, 498.000000)">\
                                  <g id="t-img_profil_arrow-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
                                      <polyline transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0"></polyline>\
                                  </g>\
                              </g>\
                          </g>\
                      </g>\
                  </svg>\
              </div>\
              <div id="t-lbl_user_name" class="pie label singleline autofit firer pageload ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="16px" dataX="1452" dataY="223" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-lbl_user_name_0"></span></div></div></div></div>\
\
          </div>\
        </div>\
      </div>\
      <div id="t-rect_already_connected" class="pie rectangle firer commentable hidden non-processed"   datasizewidth="183px" datasizeheight="77px" dataX="1163" dataY="231" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-rect_already_connected_0"></span><span id="rtr-t-rect_already_connected_1">Vous &ecirc;tes d&eacute;j&agrave; connect&eacute;.</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-1fb17292-4b39-4aa9-b71c-e445368e078f" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="LogIn" width="1920" height="1080">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/1fb17292-4b39-4aa9-b71c-e445368e078f-1585314032185.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/1fb17292-4b39-4aa9-b71c-e445368e078f-1585314032185-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/1fb17292-4b39-4aa9-b71c-e445368e078f-1585314032185-ie8.css" /><![endif]-->\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" datasizewidth="490px" datasizeheight="515px" dataX="715" dataY="384" >\
        <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="490px" datasizeheight="515px" dataX="0" dataY="0" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-Rectangle_1_0"></span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-lbl_not_signup_yet" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="140px" datasizeheight="18px" dataX="250" dataY="405" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-lbl_not_signup_yet_0">S&#039;inscrire</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-lbl_forgot_pw" class="pie richtext firer ie-background commentable non-processed"   datasizewidth="140px" datasizeheight="18px" dataX="100" dataY="405" >\
          <div class="backgroundLayer"></div>\
          <div class="paddingLayer">\
            <div class="clipping">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-lbl_forgot_pw_0">Mot de passe oub</span><span id="rtr-s-lbl_forgot_pw_1">li&eacute; ?</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-btn_signin" class="pie rectangle firer mouseenter mouseleave mousedown mouseup click commentable non-processed"   datasizewidth="160px" datasizeheight="43px" dataX="165" dataY="329" >\
         <div class="backgroundLayer"></div>\
         <div class="paddingLayer">\
           <div class="clipping">\
             <div class="content">\
               <div class="valign">\
                 <span id="rtr-s-btn_signin_0">SE CONNECTER</span>\
               </div>\
             </div>\
           </div>\
         </div>\
        </div>\
        <div id="s-txt_user_pw" class="pie password firer commentable non-processed"  datasizewidth="360px" datasizeheight="48px" dataX="65" dataY="246" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1"  placeholder="Mot de passe"/></div></div></div></div>\
        <div id="s-txt_user_name" class="pie text firer pageunload keydown pageload commentable non-processed"  datasizewidth="360px" datasizeheight="48px" dataX="65" dataY="176" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Identifiant"/></div></div>  </div></div>\
        <div id="s-lbl_signin" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="184px" datasizeheight="51px" dataX="153" dataY="90" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-lbl_signin_0">S&#039;ident</span><span id="rtr-s-lbl_signin_1">ifier</span></div></div></div></div>\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="20px" datasizeheight="20px" dataX="434" dataY="32"   alt="image" systemName="./images/a1f82593-63dc-47d9-abef-b6d5b3d65ea9.svg" overlay="#B2B2B2">\
            <?xml version="1.0" encoding="UTF-8"?>\
            <svg preserveAspectRatio=\'none\' width="20px" height="20px" viewBox="0 0 20 20" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
                <title>close-icon copy</title>\
                <desc>Created with Sketch.</desc>\
                <defs></defs>\
                <g id="s-Image_1-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                    <g id="s-Image_1-Components" transform="translate(-729.000000, -1389.000000)" fill="#B2B2B2">\
                        <g id="s-Image_1-close-icon-copy" transform="translate(729.000000, 1389.000000)">\
                            <path d="M11.768777,10.0002085 L19.6335286,2.13512894 C20.1221571,1.64689695 20.1221571,0.854718672 19.6335286,0.366486689 C19.1449,-0.12216223 18.3540055,-0.12216223 17.8649601,0.366486689 L10.0002085,8.23156622 L2.13545684,0.366486689 C1.64682829,-0.12216223 0.855099956,-0.12216223 0.36647141,0.366486689 C-0.122157137,0.854718672 -0.122157137,1.64689695 0.36647141,2.13512894 L8.23205687,10.0002085 L0.36647141,17.865288 C-0.122157137,18.3539369 -0.122157137,19.1456983 0.36647141,19.6339302 C0.610785683,19.8778378 0.930979133,20 1.25075566,20 C1.57094912,20 1.89114257,19.8778378 2.13545684,19.6335133 L10.0002085,11.7684338 L17.8649601,19.6335133 C18.1092744,19.8778378 18.4298847,20 18.7492443,20 C19.0694378,20 19.3892143,19.8778378 19.6335286,19.6335133 C20.1221571,19.1452813 20.1221571,18.353103 19.6335286,17.8648711 L11.768777,10.0002085 Z" id="s-Image_1-Fill-1"></path>\
                        </g>\
                    </g>\
                </g>\
            </svg>\
        </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;