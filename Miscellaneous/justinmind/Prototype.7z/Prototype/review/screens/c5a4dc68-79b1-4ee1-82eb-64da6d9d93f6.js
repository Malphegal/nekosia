var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1920" deviceHeight="1080">\
    <div id="t-cf63c592-a81b-4bd2-8455-dd507c76aeba" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="MainTemplate" width="1920" height="1080">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/cf63c592-a81b-4bd2-8455-dd507c76aeba-1585314032185-ie8.css" /><![endif]-->\
      <div id="t-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="1921px" datasizeheight="816px" dataX="0" dataY="264" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="t-Dynamic_Panel_1" class="pie dynamicpanel firer ie-background commentable non-processed" datasizewidth="1920px" datasizeheight="267px" dataX="0" dataY="0" >\
        <div id="t-Panel_1" class="pie panel default firer ie-background commentable non-processed"  datasizewidth="1920px" datasizeheight="267px" >\
          <div class="backgroundLayer"></div>\
          <div class="layoutWrapper scrollable">\
              <div id="t-lbl_title" class="pie label singleline autofit firer ie-background commentable non-processed"   datasizewidth="98px" datasizeheight="32px" dataX="911" dataY="212" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-lbl_title_0">Nekosia</span></div></div></div></div>\
              <div id="t-canvasPanel" class="group firer ie-background commentable non-processed" datasizewidth="72px" datasizeheight="56px" dataX="1375" dataY="204" >\
                <div id="t-fill" class="pie rectangle firer commentable non-processed"   datasizewidth="72px" datasizeheight="56px" dataX="0" dataY="0" >\
                 <div class="backgroundLayer"></div>\
                 <div class="paddingLayer">\
                   <div class="clipping">\
                     <div class="content">\
                       <div class="valign">\
                         <span id="rtr-t-fill_0"></span>\
                       </div>\
                     </div>\
                   </div>\
                 </div>\
                </div>\
                <div id="t-stroke" class="pie image firer ie-background commentable non-processed"   datasizewidth="72px" datasizeheight="56px" dataX="0" dataY="0"   alt="image" systemName="./images/87b9b3b0-2229-462d-a343-1179e5c595b0.svg" overlay="#B8BBBD">\
                    <?xml version="1.0" encoding="utf-8"?>\
                    <!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->\
                    <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">\
                    <svg preserveAspectRatio=\'none\' version="1.1" id="t-stroke-Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"\
                    	 width="609px" height="427px" viewBox="0 0 609 427" enable-background="new 0 0 609 427" xml:space="preserve">\
                    <g>\
                    	<g>\
                    		<g>\
                    			<path fill="#959A9D" d="M506.202,0.792c-118.468,0.38-237.21-0.566-352.284-0.586c-51.235,0-102.187,0-151.975,0.001H0.586v1.357\
                    				c0.055,144.49,0.107,285.629,0.161,423.685v1.196h1.195c169.352,0.045,333.996,0.088,494.081,0.13\
                    				c24.285,0.016,64.24,0.042,89.143,0.058c51.731-0.086-0.561-1.601-25.313-1.813c-155.4-1.352-325.249-1.101-462.638-0.659\
                    				c-31.797,0.082-63.576,0.165-95.273,0.248l0.843,0.842C2.5,283.491,2.558,142.154,2.703,1.564l-0.76,0.759\
                    				c203.414,0.21,405.409,0.601,605.264,0.388l-1.146-1.146c0.131,122.829,0.489,244.842,1.258,365.887\
                    				c0.108,16.961,0.544,88.711,1.054,42.538c0.521-47.271,0.156-140.818,0.104-161.295c-0.091-79.919-0.185-162.561-0.28-247.13\
                    				l-0.001-0.99l-0.987,0.002C574.073,0.647,540.211,0.72,506.202,0.792z M548.615,1.18c-2.202-0.19,14.225-0.589,17.015-0.349\
                    				C567.83,1.02,551.405,1.42,548.615,1.18z"/>\
                    		</g>\
                    	</g>\
                    </g>\
                    </svg>\
\
                </div>\
              </div>\
\
              <div id="t-img_profil_mini" class="pie image firer click ie-background commentable non-processed"   datasizewidth="40px" datasizeheight="40px" dataX="1384" dataY="212"   alt="image">\
                  <img src="resources/jim/images/common/cross.svg" />\
              </div>\
\
              <div id="t-img_header" class="pie image firer ie-background commentable non-processed"   datasizewidth="1300px" datasizeheight="194px" dataX="310" dataY="0"   alt="image">\
                  <img src="resources/jim/images/common/cross.svg" />\
              </div>\
              <div id="t-img_profil_arrow" class="pie image firer click ie-background commentable non-processed"   datasizewidth="15px" datasizeheight="7px" dataX="1427" dataY="246"   alt="image" systemName="./images/d5f0855b-91d4-4241-9003-f3fbd329993e.svg" overlay="#434343">\
                  <?xml version="1.0" encoding="UTF-8"?>\
                  <svg preserveAspectRatio=\'none\' width="23px" height="13px" viewBox="0 0 23 13" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
                      <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
                      <title>Arrow Left</title>\
                      <desc>Created with Sketch.</desc>\
                      <defs></defs>\
                      <g id="t-img_profil_arrow-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
                          <g id="t-img_profil_arrow-Components" transform="translate(-658.000000, -518.000000)" fill="#CBCBCB">\
                              <g id="t-img_profil_arrow-Inputs" transform="translate(100.000000, 498.000000)">\
                                  <g id="t-img_profil_arrow-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
                                      <polyline transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0"></polyline>\
                                  </g>\
                              </g>\
                          </g>\
                      </g>\
                  </svg>\
              </div>\
              <div id="t-lbl_user_name" class="pie label singleline autofit firer pageload ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="16px" dataX="1452" dataY="223" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-t-lbl_user_name_0"></span></div></div></div></div>\
\
          </div>\
        </div>\
      </div>\
      <div id="t-rect_already_connected" class="pie rectangle firer commentable hidden non-processed"   datasizewidth="183px" datasizeheight="77px" dataX="1163" dataY="231" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-t-rect_already_connected_0"></span><span id="rtr-t-rect_already_connected_1">Vous &ecirc;tes d&eacute;j&agrave; connect&eacute;.</span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6" class="screen growth-both devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Topic" width="1920" height="1080">\
    <div id="backgroundBox"></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6-1585314032185.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6-1585314032185-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/c5a4dc68-79b1-4ee1-82eb-64da6d9d93f6-1585314032185-ie8.css" /><![endif]-->\
      <div id="s-Rectangle_1" class="pie rectangle firer commentable non-processed"   datasizewidth="1300px" datasizeheight="99px" dataX="310" dataY="387" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_1_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-lbl_title" class="pie label singleline autofit firer pageload ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="36px" dataX="337" dataY="408" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-lbl_title_0"></span></div></div></div></div>\
      <div id="s-lbl_owner1" class="pie label singleline autofit firer pageload ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="16px" dataX="1450" dataY="416" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-lbl_owner1_0"></span></div></div></div></div>\
      <div id="s-Rectangle_2" class="pie rectangle firer commentable non-processed"   datasizewidth="1005px" datasizeheight="280px" dataX="310" dataY="501" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_2_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-lbl_owner2" class="pie label singleline autofit firer pageload ie-background commentable non-processed"   datasizewidth="10px" datasizeheight="16px" dataX="322" dataY="622" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-lbl_owner2_0"></span></div></div></div></div>\
      <div id="s-Paragraph_1" class="pie richtext firer pageload ie-background commentable non-processed"   datasizewidth="850px" datasizeheight="143px" dataX="425" dataY="530" >\
        <div class="backgroundLayer"></div>\
        <div class="paddingLayer">\
          <div class="clipping">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Line_1" class="shapewrapper shapewrapper-s-Line_1 non-processed"  rotationdeg="90" datasizewidth="200px" datasizeheight="2px" dataX="306" dataY="629" >\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Line_1" class="svgContainer" style="width:100%;height:100%;">\
              <g>\
                  <g>\
                      <path id="s-Line_1" class="pie line shape non-processed-shape firer ie-background commentable non-processed" d="M 0 1 L 200 1"  >\
                      </path>\
                  </g>\
              </g>\
              <defs>\
              </defs>\
          </svg>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed"   datasizewidth="63px" datasizeheight="65px" dataX="322" dataY="530"   alt="image">\
          <img src="resources/jim/images/common/cross.svg" />\
      </div>\
      <div id="s-Rectangle_3" class="pie rectangle firer commentable non-processed"   datasizewidth="1300px" datasizeheight="80px" dataX="310" dataY="290" >\
       <div class="backgroundLayer"></div>\
       <div class="paddingLayer">\
         <div class="clipping">\
           <div class="content">\
             <div class="valign">\
               <span id="rtr-s-Rectangle_3_0"></span>\
             </div>\
           </div>\
         </div>\
       </div>\
      </div>\
      <div id="s-btn_back_index" class="pie button singleline firer click ie-background commentable non-processed"   datasizewidth="164px" datasizeheight="29px" dataX="358" dataY="315" ><div class="backgroundLayer"></div><div class="paddingLayer"><div class="content"><div class="valign"><span id="rtr-s-btn_back_index_0">&lt;- Retourner aux topics</span></div></div></div></div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;